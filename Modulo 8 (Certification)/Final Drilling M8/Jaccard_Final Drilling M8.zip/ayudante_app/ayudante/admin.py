from django.contrib import admin
from .models import Servicio

admin.site.register(Servicio)
